import 'package:flutter/material.dart';
import 'package:simple_state_management_app/models/product.dart';

class ProductCard extends StatelessWidget {
  Product product;
  int index;
  ProductCard({super.key, required this.product, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
        color: Colors.black12,
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
      child: ListTile(
        leading: Text("${index + 1}", style: TextStyle(fontSize: 18)),
        title: Text("${product.title}", style: TextStyle(fontSize: 22)),
        subtitle: Text("Price: \$ ${product.price}"),
        trailing: IconButton(
          onPressed: () {},
          icon: Icon(Icons.delete, color: Colors.red),
        ),
      ),
    );
  }
}
