import 'package:flutter/material.dart';
import 'package:simple_state_management_app/models/product.dart';
import 'package:simple_state_management_app/services/product_service.dart';

class ProductFormScreen extends StatefulWidget {
  const ProductFormScreen({super.key});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  var productTitleController = TextEditingController();
  var priceTitleController = TextEditingController();
  var costTitleController = TextEditingController();
  var descriptionTitleController = TextEditingController();
  var productService  =ProductService();

  _onCreate(){
    Product product =  Product();
    product.title = productTitleController.text;
    product.description = descriptionTitleController.text;
    product.price = num.parse(priceTitleController.text);
    product.cost = num.parse(costTitleController.text);
    productService.createProduct(product);
    Navigator.pop(context, true);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyan,
        iconTheme: IconThemeData(color: Colors.white),
        title: Text("Create Product", style: TextStyle(color: Colors.white)),
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 35),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            TextField(
              controller: productTitleController,
              decoration: InputDecoration(hint: Text("Product name")),
            ),
            SizedBox(height: 20),
            TextField(
              controller: priceTitleController,
              decoration: InputDecoration(hint: Text("Product price")),
            ),
            SizedBox(height: 20),
            TextField(
              controller: costTitleController,
              decoration: InputDecoration(hint: Text("Product cost")),
            ),
            SizedBox(height: 20),
            TextField(
              controller: descriptionTitleController,
              decoration: InputDecoration(hint: Text("Product decription")),
            ),
            GestureDetector(
              onTap: (){
                _onCreate();
              },
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 35),
                padding: EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(
                  color: Colors.cyan,
                  borderRadius: BorderRadius.all(Radius.circular(20)),
                ),
                child: Center(
                  child: Text("Create", style: TextStyle(color: Colors.white)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
