import 'package:flutter/material.dart';
import 'package:simple_state_management_app/models/product.dart';
import 'package:simple_state_management_app/screens/product/product_form_screen.dart';
import 'package:simple_state_management_app/services/product_service.dart';

import '../../widgets/product_card.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  var productService = ProductService();
  List<Product> productList = [];

  @override
  void initState() {
    _getAllProducts();
    super.initState();
  }

  _getAllProducts() {
    setState(() {
      productList = [];
    });

    var products = productService.getAllProducts();
    if (products.isNotEmpty) {
      setState(() {
        productList.addAll(products);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyan,
        title: Text("List Product", style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProductFormScreen()),
              ).then((onValue){
                if(onValue==true){
                  _getAllProducts();
                }
              });
            },
            icon: Icon(Icons.add, color: Colors.white),
          ),
        ],
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: ListView.builder(
          itemCount: productList.length,
          itemBuilder: (context, index) {
            var product = productList[index];
            return ProductCard(product: product, index: index,);
          },
        ),
      ),
    );
  }
}
