import 'package:simple_state_management_app/models/product.dart';

class ProductService {
  static List<Product> productList = [];

  List<Product> getAllProducts() {
    return productList;
  }

  void createProduct(Product req) {
    req.id = productList.length + 1;
    productList.add(req);
  }

  void updateProduct(Product req) {
    var index = productList.indexWhere((data) => data.id == req.id);
    if (index != -1) {
      productList.insert(index, req);
    }
  }

  void deleteProduct(int id) {
    var index = productList.indexWhere((data) => data.id == id);
    if (index != -1) {
      productList.removeAt(index);
    }
  }

  Product getProductById(int id) {
    return productList.where((data) => data.id == id).first;
  }
}
