class Product {
  int? id;
  String? title;
  String? description;
  num? price;
  num? cost;

  Product({
    this.id,
    this.title,
    this.description,
    this.price,
    this.cost});
}
